# learning_mongo
Exercise files for the Learning Mongo course on Lynda
